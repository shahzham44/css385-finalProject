using System.Collections;
using UnityEngine;

public class NoiseBehavior : MonoBehaviour
{
    public GameObject circlePrefab;
    private PlayerBehavior player;
    private GameObject currentCircle; // Track the current spawned circle

    private float shrinkSpeed;

    private void Start()
    {
        player = FindObjectOfType<PlayerBehavior>();
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            // Spawn a circle only if there isn't already one spawned
            if (currentCircle == null)
            {
                //SpawnCircle();
            }
        }
    }

    // Spawn the circle around player
    public void SpawnCircle()
    {
        float circleMaxSize = 0f;

        if (player.isUsingRifle())
        {
            circleMaxSize = 125f;
            shrinkSpeed = 500f;
        } else
        {
            circleMaxSize = 350f;
            shrinkSpeed = 800f;
        }

        currentCircle = Instantiate(circlePrefab, transform.position, Quaternion.identity);
        currentCircle.transform.localScale = new Vector3(circleMaxSize, circleMaxSize, 1f);
        StartCoroutine(ShrinkCircle(currentCircle));
    }

    // Shrink the circle gradually
    IEnumerator ShrinkCircle(GameObject circle)
    {
        while (circle.transform.localScale.x > 0f)
        {
            float newScale = circle.transform.localScale.x - shrinkSpeed * Time.deltaTime;
            newScale = Mathf.Max(newScale, 0f);
            circle.transform.localScale = new Vector3(newScale, newScale, 1f);
            yield return null;
        }

        Destroy(circle);
        currentCircle = null; // Reset currentCircle when the circle is destroyed
    }
}
