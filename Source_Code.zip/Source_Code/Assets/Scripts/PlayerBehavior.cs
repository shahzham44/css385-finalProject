using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerBehavior : MonoBehaviour
{
    private NoiseBehavior noiseBehavior;
    private GameController gameController;

    [SerializeField] private FieldOfView fieldOfView;
    private float moveSpeed = 50f;
    private bool canFire = true;
    private bool rifleInUse = true;
    private bool restartStatus;

    private int magazineCount = 4;
    // private int magazineCapacity = 10; // Just reference
    private int bulletPosition = 10;

    private int shellCount = 24;
    // private int shotgunCapacity = 8; // Just reference
    private int shellPosition = 8;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1;
        restartStatus = false;
        noiseBehavior = FindFirstObjectByType<NoiseBehavior>();
        gameController = GameObject.FindFirstObjectByType<GameController>();
        
    }

    // Update is called once per frame
    void Update()
    {
        PlayerInput();

        FaceMouse();

        FireControls();

        if (restartStatus && Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadSceneAsync(3);
        }
    }

    private void PlayerInput()
    {
        // [MOVEMENT] - WASD 
        if (Input.GetKey(KeyCode.W))
        {
            // Move up
            transform.position += Vector3.up * moveSpeed * Time.smoothDeltaTime;
        }
        if (Input.GetKey(KeyCode.S))
        {
            // Move down
            transform.position += Vector3.down * moveSpeed * Time.smoothDeltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            // Move right
            transform.position += Vector3.right * moveSpeed * Time.smoothDeltaTime;
        }
        if (Input.GetKey(KeyCode.A))
        {
            // Move left
            transform.position += Vector3.left * moveSpeed * Time.smoothDeltaTime;
        }

        // [MOVEMENT] - Sprinting
        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            moveSpeed *= 2;
        }
        else if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            moveSpeed /= 2;
        }

        // [WEAPON SWAPPING] - Rifle/Shotgun Modes
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            rifleInUse = true;
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            rifleInUse = false;
        }

        // [RELOADING] - What do you think it is?
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (rifleInUse && magazineCount >= 1 && bulletPosition != 10)
            {
                bulletPosition = 10;
                magazineCount--;
            } else if (!rifleInUse && shellCount >= 1)
            {
                while (shellPosition < 8)
                {
                    shellPosition++;
                    shellCount--;
                }
            }
        }
    }
    /** FaceMouse()
     * ------------
     * Player forced to turn towards the mouse position at all times.
     * fieldOfView object used to allow the player's vision cone to
     * match the direction they are looking.
     */
    private void FaceMouse()
    {
        Vector3 mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

        Vector2 direction = new Vector2(
            mousePosition.x - transform.position.x,
            mousePosition.y - transform.position.y);

        transform.up = direction;

        // aiowdjfaw
        fieldOfView.SetAimDirection(direction);
        fieldOfView.SetOrigin(transform.position);
    }

    /** FireControls()
     * ---------------
     * Player shooting occurs here. Default magazine count for the
     * rifle is 4, each magazine contains 30 rounds. Default shotgun shell
     * count is 32, 8 shells can be loaded at a time. 
     * Rounds/shells will only fired if sufficient ammo exists in the breach/magazine.
     */
    private void FireControls()
    {
        if (Input.GetMouseButton(0) && canFire)
        {
            if (rifleInUse && bulletPosition > 0)
            {
                StartCoroutine(FireRifle());
            } else if (!rifleInUse && shellPosition > 0)
            { 
                StartCoroutine(FireShotgun()); 
            }
        }
    }

    /** FireRifle()
     * ------------
     * Rifle bullets come out of the rifle in the direction the 
     * player/firearm is facing.
     * 
     * - canFire prevents spawm firing.
     * - right/upOffset used to position spawn location to player's firearm
     */
    IEnumerator FireRifle()
    {
        canFire = false;
        GameObject bullet;
        noiseBehavior.SpawnCircle();

        bullet = Instantiate(Resources.Load("Prefabs/Standard Round") as GameObject);
        
        Vector3 rightoffset = transform.right * 4f;
        Vector3 upOffset = transform.up * 12f;

        bullet.transform.position = transform.position + rightoffset + upOffset;

        // Generate a random angle for the bullet
        float minAngle = -1f;
        float maxAngle = 1f;
        float angle = Random.Range(minAngle, maxAngle);

        // Bullet angle variation
        bullet.transform.rotation = Quaternion.Euler(transform.rotation.eulerAngles + new Vector3(0, 0, angle));

        // Control rate of fire
        yield return new WaitForSeconds(0.05f);
        canFire = true;

        // Bullet fired, cycle next round
        bulletPosition--;
    }

    /** FireShotgun()
     * --------------
     * Shotgun pellets come out of the (rifle), with a random count
     * ranging from 5-8 pellets at varying angles. 
     * 
     * - canFire prevents spam firing.
     * - min/maxBullets cause varying pellet counts, used in numBullets
     * - min/maxAngle cause varying angles
     * - for loop repeats however many bullets will be created
     * - right/upOffset used to position spawn location to player's firearm
     */
    IEnumerator FireShotgun()
    {
        canFire = false;
        noiseBehavior.SpawnCircle();

        // Shell fired, cycle next shell
        shellPosition--;

        // Define the range for the number of bullets and their angles
        int minBullets = 5;
        int maxBullets = 8;
        float minAngle = -10f;
        float maxAngle = 10f;

        // numBullets will be 5 to 8 inclusive
        int numBullets = Random.Range(minBullets, maxBullets + 1);

        // random shotgun shell number? 
        for (int i = 0; i < numBullets; i++)
        {
            GameObject bullet = Instantiate(Resources.Load("Prefabs/Shotgun Pellet") as GameObject);

            // Used in positioning bullet spawn location
            Vector3 rightoffset = transform.right * 4f;
            Vector3 upOffset = transform.up * 12f;

            // Bullet spawn location at the end of player's firearm
            bullet.transform.position = transform.position + rightoffset + upOffset;

            // Generate a random angle for the bullet
            float angle = Random.Range(minAngle, maxAngle);

            // Adjust the rotation of the bullet
            bullet.transform.rotation = Quaternion.Euler(transform.rotation.eulerAngles + new Vector3(0, 0, angle));
        }

        // Control rate of fire
        yield return new WaitForSeconds(0.8f);
        canFire = true;
    }

    /**
     * isUsingRifle()
     * --------------
     * Ima be honest I forgot where I'm using this but I'm too tired rn 
     * but i mean come on look at the name of the function
     */
    public bool isUsingRifle()
    {
        return rifleInUse;
    }

    /**
     * OnCollisionEnter2D()
     * --------------------
     * Player interactions with world and stuff.
     */
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Gold")
        {
            gameController.incrementGold();

            Destroy(collision.gameObject);
        }
        if (collision.gameObject.tag == "Enemy")
        {
            restartStatus = true;
            gameController.playerHitRestart();
        }
    }

    // Accessor Methods for GameController to use (hopefully) in the UI
    public int getMagazineCount()
    {
        return magazineCount;
    }

    public int getBulletPosition()
    {
        return bulletPosition;
    }

    public int getShellCount()
    {
        return shellCount;
    }
    public int getShellPosition()
    {
        return shellPosition;
    }    
}
