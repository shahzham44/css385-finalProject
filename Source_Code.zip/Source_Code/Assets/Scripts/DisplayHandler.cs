using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DisplayHandler : MonoBehaviour
{
    public Text ammoCounterDisplay = null;
    public Text magazineCounterDisplay = null;
    public Text respawnTimerDisplay = null;
    public Text goldCounterDisplay = null;
    public Text weaponTypeDisplay = null;

    private PlayerBehavior player;
    private SpawnManager spawnManager;
    private GameController gameController;

    // Start is called before the first frame update
    void Start()
    {
        player = FindFirstObjectByType<PlayerBehavior>();
        spawnManager = FindFirstObjectByType<SpawnManager>();
        gameController = FindFirstObjectByType<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        respawnTimerDisplay.text = string.Format("Time left until next wave: {0:F2}", spawnManager.getRespawnTimer());
        goldCounterDisplay.text = "Gold Collected: " + gameController.getGoldCount() + "/6";

        if (player.isUsingRifle())
        {
            ammoCounterDisplay.text = "Ammo: " + player.getBulletPosition() + "/10";
            magazineCounterDisplay.text = "Magazines Left: " + player.getMagazineCount();
            weaponTypeDisplay.text = "Current Weapon: Rifle";
        } else
        {
            ammoCounterDisplay.text = "Ammo: " + player.getShellPosition() + "/8";
            magazineCounterDisplay.text = "Shells Left: " + player.getShellCount();
            weaponTypeDisplay.text = "Current Weapon: Shotgun";
        }
        
    }
}
