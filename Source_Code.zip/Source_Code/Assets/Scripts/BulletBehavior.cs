using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehavior : MonoBehaviour
{
    private SpawnManager spawnManager;
    private const float bulletSpeed = 536f;

    void Start()
    {   
    }

    void Update()
    {
        transform.position += transform.up * (bulletSpeed * Time.smoothDeltaTime);
        spawnManager = FindFirstObjectByType<SpawnManager>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Wall") || collision.CompareTag("Fence"))
        {
            Destroy(gameObject);
        }
        if (collision.CompareTag("Glass"))
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }

        if (collision.CompareTag("Enemy"))
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
            spawnManager.decrementEnemyCount();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //if (collision.gameObject.CompareTag("Enemy"))
        //{
        //    Destroy(collision.gameObject);
        //    Destroy(gameObject);
        //}
    }

    private void OnBecameInvisible()
    {
        Destroy(transform.gameObject);
    }
}
