using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletBehavior : MonoBehaviour
{
    private float bulletSpeed = 230f;

    // Start is called before the first frame update
    void Start()
    {
    }

    void Update()
    {
        transform.position += transform.up * (bulletSpeed * Time.smoothDeltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Wall") || collision.CompareTag("Fence"))
        {
            Destroy(gameObject);
        }
        if (collision.CompareTag("Glass"))
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }

        if (collision.CompareTag("Player"))
        {
            Destroy(gameObject);
            Debug.Log("Game Over!");
            Application.Quit();
        }
    }
}