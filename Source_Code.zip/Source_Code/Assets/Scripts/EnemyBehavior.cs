using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class EnemyBehavior : MonoBehaviour
{
    [SerializeField] public Transform target;
    public NavMeshAgent agent;

    private float speed = 50.0f;
    public float radius = 50.0f;
    private float angle = 360.0f;
    public GameObject player;
    private GameController gameController;
    private bool detectPlayer;

    private bool movingRight = true;
    public float moveSpeed = 30f;
    public float patrolRange = 40f;
    private Vector3 originalPosition;
    public bool moveHorizontally = true;
    private bool movingUp = true;

    public bool canFire = true;
    public bool canMove = true;

    private float distanceToPlayer;


    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;

        player = GameObject.FindGameObjectWithTag("Player");
        gameController = GameObject.FindFirstObjectByType<GameController>();
        StartCoroutine(isSomethingInVision());

        originalPosition = transform.position;

    }

    //Referenced using: https://www.youtube.com/watch?v=OQ1dRX5NyM0
    private IEnumerator isSomethingInVision()
    {
        WaitForSeconds waitTime = new WaitForSeconds(0.2f);
        while (true)
        {
            yield return waitTime;
            SomethingInVision();
        }
    }

    private void SomethingInVision()
    {
        Collider2D[] overallRange = Physics2D.OverlapCircleAll(transform.position, radius, LayerMask.GetMask("Player"));
        if (overallRange.Length > 0)
        {
            Transform currentTarget = overallRange[0].transform;
            Vector2 direction = (currentTarget.position - transform.position).normalized;
            if (Vector2.Angle(transform.up, direction) < angle / 2)
            {
                float distance = Vector2.Distance(transform.position, currentTarget.position);
                if (!Physics2D.Raycast(transform.position, direction, distance, LayerMask.GetMask("Wall")))
                {
                    detectPlayer = true;
                    gameController.playerFound();

                    if (distanceToPlayer >= 100)
                    {
                        if (canFire)
                        {
                            StartCoroutine(FireRound());
                        }
                    }
                }
                else
                {
                    //detectPlayer = false;
                }
            }
            else
            {
                //detectPlayer = false;
            }
        }
        else if (detectPlayer)
        {
            //detectPlayer = false;
        }
    }

    // Referenced: https://www.youtube.com/watch?v=xDg2pxqJHq4
    // Update is called once per frame
    void Update()
    {
        distanceToPlayer = Vector3.Distance(transform.position, player.transform.position);

        if (detectPlayer || gameController.playerIsFound())
        {
            if (canMove)
            {
                agent.SetDestination(target.position);
            }


            //Debug.Log("Chasing Player");
            //Vector2 direction = player.transform.position - transform.position;
            //float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
            // Quaternion rotation = Quaternion.Euler(new Vector3(0, 0, angle));
            //transform.rotation = Quaternion.Slerp(transform.rotation, rotation, speed * Time.deltaTime);
            // transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.smoothDeltaTime);

        }
        else if (canMove)
        {
            if (moveHorizontally)
            {
                MoveHorizontally();
            }
            else
            {
                MoveVertically();
            }
        }
    }

    void MoveHorizontally()
    {
        Vector3 direction = movingRight ? Vector3.right : Vector3.left;

        transform.Translate(direction * moveSpeed * Time.deltaTime);

        if (movingRight && transform.position.x >= (originalPosition.x + patrolRange) ||
            !movingRight && transform.position.x <= (originalPosition.x - patrolRange))
        {
            movingRight = !movingRight;
        }
    }

    void MoveVertically()
    {
        Vector3 direction = movingUp ? Vector3.up : Vector3.down;
        transform.Translate(direction * moveSpeed * Time.deltaTime);

        if (movingUp && transform.position.y >= (originalPosition.y + patrolRange) ||
            !movingUp && transform.position.y <= (originalPosition.y - patrolRange))
        {
            movingUp = !movingUp;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Noise"))
        {
            detectPlayer = true;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("GAME OVER");
            gameController.playerHitRestart();
        }
    }

    IEnumerator FireRound()
    {

        Debug.Log("Enemy fired round"); // Not seen
        canFire = false;
        GameObject bullet;

        bullet = Instantiate(Resources.Load("Prefabs/Enemy Round") as GameObject);
        bullet.transform.position = transform.position;

        // Assuming 'player' is a reference to the player's GameObject
        Vector3 directionToPlayer = player.transform.position - transform.position;
        float angleToPlayer = Mathf.Atan2(directionToPlayer.y, directionToPlayer.x) * Mathf.Rad2Deg - 90;
        transform.up = player.transform.position - transform.position;

        // Bullet faces the player
        bullet.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angleToPlayer));

        // Control rate of fire
        yield return new WaitForSeconds(1f);
        canFire = true;
    }
}
