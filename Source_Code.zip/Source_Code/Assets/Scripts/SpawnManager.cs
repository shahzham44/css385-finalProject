using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public EnemyBehavior[] enemyPrefabs;
    public GameObject[] spawnLocations;

    public GameController gameController;
    public DisplayHandler displayHandler;

    public int enemyCount = 7;

    public float respawnTimer = 0;
    private float respawnTimeLimit = 15f;
    private int additionalEnemiesToSpawn = 5;

    // Start is called before the first frame update
    void Start()
    {
        gameController = GameObject.FindFirstObjectByType<GameController>();
        respawnTimer = respawnTimeLimit;
    }

    // Update is called once per frame
    void Update()
    {
        if (gameController.playerIsFound())
        {
            // Countdown the timer
            respawnTimer -= Time.deltaTime;

            if (respawnTimer <= 0f)
            {
                // Spawn additional enemies
                for (int i = 0; i < additionalEnemiesToSpawn; i++)
                {
                    SpawnEnemy();
                }

                respawnTimer = respawnTimeLimit;
            }
        }
    }

    private void SpawnEnemy()
    {
        EnemyBehavior enemyPrefab = enemyPrefabs[0];
        GameObject spawnLocation = spawnLocations[Random.Range(0, spawnLocations.Length)];

        // Instantiate the enemy prefab
        EnemyBehavior newEnemy = Instantiate(enemyPrefab, spawnLocation.transform.position, Quaternion.identity);

        // Assign the target location to the newly spawned enemy
        newEnemy.player = gameController.player;
        newEnemy.target = gameController.playerLocation;

        // Increment enemy count
        enemyCount++;
    }

    public void decrementEnemyCount()
    {
        enemyCount--;
    }

    public float getRespawnTimer()
    {
        return respawnTimer;
    }
}
