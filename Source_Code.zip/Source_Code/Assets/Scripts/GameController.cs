using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameController : MonoBehaviour
{
    private int goldCount = 0;
    public GameObject player;
    public Text restart;
    public Text wereHit;
    public PlayerBehavior playerBehavior;
    public GameObject playerInfo;
    private bool restartStatus;

    private bool chase = false;
    public Transform playerLocation;

    public Image map;
    public Image mapBorder;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1;
        player = GameObject.FindGameObjectWithTag("Player");
        restartStatus = false;
        restart.enabled = false;
        wereHit.enabled = false;
        restartStatus = false;
        map.enabled = false;
        mapBorder.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        playerLocation = player.transform;

        if (goldCount == 6)
        {
            restart.enabled = true;
            restartStatus = true;
            Debug.Log("COLLECTED ALL GOLD");
            Time.timeScale = 0;
        }

        if (restartStatus && Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadSceneAsync(3);
        }

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            map.enabled = !map.enabled;
            mapBorder.enabled = !mapBorder.enabled;
            playerInfo.SetActive(!playerInfo.activeInHierarchy);
        }

        //Debug.Log("Rifle magazines: " + player.getMagazineCount());
        //Debug.Log("Rounds remaining: " + player.getBulletPosition());
        //Debug.Log("Shotgun shells: " + player.getShellCount());
        //Debug.Log("Shells remaining: " + player.getShellPosition());
    }
    
    public void incrementGold()
    {
        goldCount++;
    }

    public int getGoldCount()
    {
        return goldCount;
    }

    public bool playerIsFound()
    {
        return chase;
    }

    public void playerFound()
    {
        chase = true;
    }

    public void playerHitRestart()
    {
        restartStatus = true;
        wereHit.enabled = true;
        Time.timeScale = 0;
    }
}
