The version of Unity being used is 2023.2.14f1

Website: https://sites.google.com/uw.edu/gold-runner/home